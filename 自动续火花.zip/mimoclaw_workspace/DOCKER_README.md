# 抖音自动续火花 - 飞牛NAS Docker 部署指南

## 前置条件

- 飞牛NAS（fnOS）已安装并正常运行
- NAS 已安装 Docker 套件（fnOS 自带）
- NAS 有正常的网络连接

---

## 第一步：配置 Docker 镜像源（重要！）

国内环境直接构建大概率会失败，必须先换源。

1. 打开飞牛NAS的 **Docker 管理面板**
2. 进入 **镜像仓库** → **仓库设置**
3. 将默认镜像源替换为以下两个：

```
https://docker.1ms.run
https://docker.1panel.live
```

4. 设置完成后，在 Docker 面板右上角 **停止** 再 **启动** Docker 服务

---

## 第二步：上传项目文件

1. 打开飞牛NAS的 **文件管理**
2. 选择一个存储空间（建议选非系统盘，比如 `vol2`），路径示例：

```
/vol2/1000/docker/tiktok-spark
```

3. 将本项目的压缩包 `TikTokAutoSparkWeb-docker.tar.gz` 上传到该目录
4. 解压（如果NAS支持直接解压），或者通过 SSH 执行：

```bash
cd /vol2/1000/docker/tiktok-spark
tar xzf TikTokAutoSparkWeb-docker.tar.gz
mv TikTokAutoSparkWeb/* .
rm -rf TikTokAutoSparkWeb TikTokAutoSparkWeb-docker.tar.gz
```

**最终目录结构应为：**

```
/vol2/1000/docker/tiktok-spark/
├── backend.py
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
├── docker/
│   ├── nginx.conf
│   └── entrypoint.sh
├── package.json
├── package-lock.json
├── index.html
├── src/
├── public/
├── .dockerignore
├── DOCKER_README.md
├── README.md
└── LICENSE.txt
```

---

## 第三步：创建 Docker Compose 项目

1. 打开飞牛NAS的 **Docker 管理面板**
2. 点击左侧 **Compose** → **创建项目**
3. 填写信息：
   - **项目名称**：`tiktok-spark`（自定义即可）
   - **路径**：选择刚才上传文件的目录，如 `/vol2/1000/docker/tiktok-spark`
4. 点击 **确定**，飞牛会自动读取目录下的 `docker-compose.yml`
5. 点击 **构建**，等待完成（首次构建需要下载 Chrome + Python 依赖，大约 5-15 分钟）

---

## 第四步：访问服务

构建成功后，容器状态会变为绿色 **运行中**。

打开浏览器访问：

```
http://你的飞牛NAS内网IP:8080
```

例如：`http://192.168.1.100:8080`

**默认登录信息：**
- 账号：`admin`
- 密码：`123456`

> ⚠️ 首次登录后建议立即在 **设置** 页面修改密码

---

## 第五步：使用流程

1. **登录** → 打开网页，用 admin/123456 登录
2. **初始化浏览器** → 首页点击「初始化浏览器」
3. **扫码登录抖音** → 用抖音 App 扫描二维码授权
4. **查看好友** → 进入好友列表，确认好友信息
5. **添加定时任务** → 为好友设置每日自动发送消息的时间

---

## 常用操作

### 查看日志

在飞牛 Docker 面板 → 点击项目 → 查看日志

### 重启项目

在飞牛 Docker 面板 → 点击项目 → 右上角重启

### 修改端口

编辑 `docker-compose.yml`，修改端口映射：

```yaml
ports:
  - "自定义端口:8080"   # 例如 "9090:8080"
```

修改后在飞牛面板重新构建项目。

### 修改密码

编辑 `docker-compose.yml`，修改环境变量：

```yaml
environment:
  - ADMIN_PASSWORD=你的新密码
```

修改后在飞牛面板重新构建项目。

### 清除登录状态（重新扫码）

在飞牛 Docker 面板 → 停止项目 → 删除项目（不勾选删除文件）

然后删除持久化数据：

```bash
# 通过 SSH 或文件管理器删除
rm -rf /vol2/1000/docker/tiktok-spark/chrome-profile
```

重新构建项目即可。

---

## 环境变量说明

在 `docker-compose.yml` 的 `environment` 部分修改：

| 变量 | 默认值 | 说明 |
|------|--------|------|
| `HEADLESS` | `true` | 无头模式，保持 `true` 即可 |
| `ADMIN_PASSWORD` | `123456` | 管理员登录密码 |
| `TZ` | `Asia/Shanghai` | 时区 |

---

## 常见问题

### Q: 构建失败，提示网络超时

**A:** 确认已按第一步配置了 Docker 镜像源。如果仍然失败，尝试在 NAS 的 Docker 面板重启 Docker 服务后重新构建。

### Q: 构建成功但访问不了

**A:** 检查以下几点：
1. 容器是否为绿色「运行中」状态
2. NAS 防火墙是否放行了 8080 端口
3. 浏览器访问地址是否正确（`http://` 不是 `https://`）

### Q: 初始化浏览器失败

**A:** 首次启动可能需要几秒钟初始化 Chrome，稍等片刻后重试。如果持续失败，查看容器日志排查。

### Q: 扫码登录后提示「二次验证」

**A:** 这是抖音的安全机制，需要在弹出的页面中完成手机验证码验证。由于是 headless 模式，你可以在网页端的截图功能中查看当前页面状态。

### Q: 如何更新版本？

**A:**
1. 上传新的项目文件覆盖旧文件
2. 在飞牛 Docker 面板停止并删除项目（不勾选删除文件）
3. 重新创建项目并构建

---

## 外网访问（可选）

如果需要从外网访问，有以下方案：

1. **飞牛 FN Connect**：飞牛自带的内网穿透服务，在系统设置中开启
2. **端口映射**：在路由器中将 NAS 的 8080 端口映射到外网
3. **Tailscale/ZeroTier**：安装在 NAS 上，通过虚拟局域网访问

> ⚠️ 外网访问存在安全风险，建议修改默认密码并考虑使用反向代理 + HTTPS

---

## 技术架构

```
┌──────────────────────────────────────────┐
│           飞牛NAS Docker 容器             │
│                                          │
│   ┌──────────┐    ┌──────────────────┐   │
│   │  nginx   │    │  Python Backend  │   │
│   │  :8080   │───▶│  FastAPI :9844   │   │
│   │          │    │                  │   │
│   │ 前端页面  │    │  ┌────────────┐  │   │
│   │ /api反代  │    │  │  Chrome    │  │   │
│   └──────────┘    │  │  (headless) │  │   │
│                    │  └────────────┘  │   │
│                    └──────────────────┘   │
│                                          │
│   chrome-profile (Volume 持久化登录状态)   │
└──────────────────────────────────────────┘
```

浏览器访问 `http://NAS-IP:8080` → nginx 提供前端页面 + 反代 API → Python 后端驱动 Chrome 自动化操作抖音。
