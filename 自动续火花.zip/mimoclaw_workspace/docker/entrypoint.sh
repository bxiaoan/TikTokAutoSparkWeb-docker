#!/bin/bash
set -e

# 创建 Chrome profile 目录
mkdir -p "${CHROME_PROFILE_DIR:-/app/chrome-profile}"

echo "============================================"
echo "  抖音自动续火花 Docker 版"
echo "============================================"
echo "  后端端口: 9844"
echo "  前端端口: 8080"
echo "  Headless: ${HEADLESS:-true}"
echo "  Chrome:   ${CHROME_BINARY:-/opt/google/chrome/chrome}"
echo "============================================"

# 启动后端（后台）
cd /app
python backend.py &
BACKEND_PID=$!

# 等待后端启动
echo "⏳ 等待后端启动..."
for i in $(seq 1 30); do
    if curl -s http://127.0.0.1:9844/Home > /dev/null 2>&1; then
        echo "✅ 后端已启动"
        break
    fi
    sleep 1
done

# 启动 nginx（前台）
echo "🚀 启动 nginx..."
nginx -g 'daemon off;' &
NGINX_PID=$!

# 信号处理
_term() {
    echo "🛑 收到停止信号，正在关闭..."
    kill $NGINX_PID 2>/dev/null
    kill $BACKEND_PID 2>/dev/null
    wait $NGINX_PID 2>/dev/null
    wait $BACKEND_PID 2>/dev/null
    exit 0
}
trap _term SIGTERM SIGINT

# 等待任意子进程退出
wait -n $BACKEND_PID $NGINX_PID
